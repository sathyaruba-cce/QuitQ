// src/app/models/cart.model.ts

import { Product } from './product.model';
import { User } from './user.model';

export interface CartItem {
  id?: number;
  quantity: number;
  user_id: number;
  product_id: number;
  product?: Product; 
}

