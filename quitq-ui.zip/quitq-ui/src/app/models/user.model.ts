// src/app/models/user.model.ts

export type Role = 'ADMIN' | 'USER' | 'SELLER';  // ✅ Include all enum values from Java backend

export interface User {
  id?: number;           // Optional if it's auto-generated
  name: string;
  email: string;
  password: string;
  gender: string;
  contactNumber: string;
  address: string;
  role: Role;
}
