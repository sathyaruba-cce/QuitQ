import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router';

import { CartService } from '../../../services/cart.service';
import { CartItem } from '../../../models/cart.model';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  templateUrl: './cart.html',
  styleUrls: ['./cart.css'],
  imports: [CommonModule, HttpClientModule, RouterModule]
})
export class CartComponent implements OnInit {
  cartItems: CartItem[] = [];

  constructor(
    private cartService: CartService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadCartItems();
  }

  // ✅ Load and store in localStorage
  loadCartItems(): void {
    this.cartService.getCartItems().subscribe({
      next: (items) => {
        this.cartItems = items.map(item => {
          if (item.product) item.product.imageError = false;
          return item;
        });

        // ✅ Store simplified cart in localStorage
        const simpleCart = this.cartItems.map(item => ({
          name: item.product?.name,
          price: item.product?.price,
          quantity: item.quantity
        }));

        localStorage.setItem('cart', JSON.stringify(simpleCart));
      },
      error: (err) => console.error(err)
    });
  }

  increaseQty(item: CartItem): void {
    item.quantity++;
    this.updateCart(item);
  }

  decreaseQty(item: CartItem): void {
    if (item.quantity > 1) {
      item.quantity--;
      this.updateCart(item);
    }
  }

  updateCart(item: CartItem): void {
    this.cartService.updateCartItem(item.product!.id, item.quantity).subscribe({
      next: () => this.loadCartItems(), // ✅ Reload and re-save to localStorage
      error: (err) => console.error('❌ Failed to update quantity', err)
    });
  }

  removeItem(productId: number): void {
    this.cartService.removeItem(productId).subscribe({
      next: () => this.loadCartItems(), // ✅ Reload and re-save to localStorage
      error: (err) => console.error('❌ Failed to remove item', err)
    });
  }

  getTotal(): number {
    return this.cartItems.reduce(
      (total, item) => total + (item.product?.price || 0) * item.quantity,
      0
    );
  }

  checkout(): void {
    if (!this.authService.getToken()) {
      alert('Please login to proceed to checkout');
      this.router.navigate(['/login']);
      return;
    }

    this.router.navigate(['/checkout']);
  }
}
