// src/app/components/user/order-history/order-history.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-order-history',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './order-history.html',
  styleUrls: ['./order-history.css']
})
export class OrderHistoryComponent {
  orders: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    const email = localStorage.getItem('email');
    const token = localStorage.getItem('token');

    this.http.get<any[]>(`http://localhost:8081/user/orders?email=${email}`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    }).subscribe(data => {
      // ✅ Add fallback image
      this.orders = data.map(order => ({
        ...order,
        items: order.items.map((item: any) => ({
          ...item,
          image: item.image || 'src/assets/default.jpg'
        }))
      }));
    });
  }
}
