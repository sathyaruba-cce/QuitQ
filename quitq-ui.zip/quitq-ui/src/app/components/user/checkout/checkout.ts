// src/app/components/user/checkout/checkout.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './checkout.html',
  styleUrls: ['./checkout.css']
})
export class CheckoutComponent implements OnInit {
  shippingAddress: string = '';
  paymentMethod: string = 'COD';
  cartItems: any[] = [];
  totalAmount: number = 0;

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    const nav = this.router.getCurrentNavigation();
    const state = nav?.extras?.state as { totalAmount?: number };

    const cart = localStorage.getItem('cart');
    if (cart) {
      const rawItems = JSON.parse(cart);

      this.cartItems = rawItems.map((item: any) => {
        const product = item.product || {};
        return {
          name: product.name || item.name,
          price: product.price || item.price || 0,
          quantity: item.quantity || 1,
          image: product.image || item.image || 'src/assets/default.jpg'
        };
      });

      this.totalAmount = state?.totalAmount && state.totalAmount > 0
        ? state.totalAmount
        : this.cartItems.reduce(
            (sum, item) => sum + item.price * item.quantity,
            0
          );
    }

    console.log('✅ Final Cart Items:', this.cartItems);
    console.log('✅ Calculated Total:', this.totalAmount);
  }

  placeOrder(): void {
    const email = localStorage.getItem('email');
    const token = localStorage.getItem('token');

    if (!email || !token) {
      alert('❌ Login required to place an order');
      this.router.navigate(['/login']);
      return;
    }

    if (!this.shippingAddress.trim()) {
      alert('❌ Please enter a shipping address');
      return;
    }

    const order = {
      userEmail: email,
      shippingAddress: this.shippingAddress,
      totalAmount: this.totalAmount,
      items: this.cartItems.map(item => ({
        productName: item.name,
        price: item.price,
        quantity: item.quantity,
        total: item.price * item.quantity
      }))
    };

    this.http.post('http://localhost:8081/api/orders', order, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    }).subscribe({
      next: () => {
        alert('✅ Order placed successfully!');
        localStorage.removeItem('cart');
        this.router.navigate(['/user/order-history']);
      },
      error: err => {
        console.error('❌ Order placement failed', err);
        alert('❌ Something went wrong. Try again later.');
      }
    });
  }
}
