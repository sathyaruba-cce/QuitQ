import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Product } from '../../../models/product.model';
import { ProductService } from '../../../services/product.service';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-list.html',
  styleUrls: ['./product-list.css']
})
export class ProductListComponent implements OnInit {
  products: (Product & { imageError?: boolean })[] = [];
  searchTerm = '';

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private router: Router // ✅ router added
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const query = params['q'];
      if (query) {
        this.searchTerm = query;
        this.searchProducts(query);
      } else {
        this.loadAllProducts();
      }
    });
  }

  loadAllProducts(): void {
    this.productService.getAllProducts().subscribe({
      next: (res) => {
        this.products = res.map(p => ({ ...p, imageError: false }));
      },
      error: (err) => console.error('Error fetching products:', err)
    });
  }

  searchProducts(query: string): void {
    this.productService.searchProducts(query).subscribe({
      next: (res) => {
        this.products = res.map(p => ({ ...p, imageError: false }));
      },
      error: (err) => console.error('Search failed:', err)
    });
  }

  goToDetails(id: number): void {
    this.router.navigate(['/product-details', id]); // ✅ Corrected path
  }
}
