import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { CartService } from '../../../services/cart.service';
import { Product } from '../../../models/product.model';
import { AuthService } from '../../../services/auth.service';
import { ProductService } from '../../../services/product.service';

@Component({
  selector: 'app-product-details',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './product-details.html',
  styleUrls: ['./product-details.css']
})
export class ProductDetailsComponent implements OnInit {
  product!: Product;
  imageError: boolean = false;
  quantity: number = 1; // default quantity

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private cartService: CartService,
    private authService: AuthService,
    private productService: ProductService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      const productId = parseInt(id, 10);
      this.productService.getProductById(productId).subscribe({
        next: (res) => {
          this.product = res;
          this.product.imageError = false;
        },
        error: (err) => {
          console.error('Failed to fetch product:', err);
          this.router.navigate(['/home']); // Redirect if invalid ID
        }
      });
    } else {
      this.router.navigate(['/home']); // No ID provided
    }
  }

  addToCart(): void {
    const user = this.authService.getLoggedInUser();

    if (!user) {
      alert('Please login to add to cart');
      this.router.navigate(['/login']);
      return;
    }

    // ✅ Fix: Match backend's expected format: productId and quantity
    const request = {
      productId: this.product.id,
      quantity: this.quantity
    };

    console.log('🛒 Sending to cart endpoint:', request);

    this.cartService.addToCart(request).subscribe({
      next: (res) => {
        console.log('✅ Successfully added to cart:', res);
        alert('Item added to cart!');
        this.router.navigate(['/cart']);
      },
      error: (err) => {
        console.error('❌ Error adding to cart:', err);
        alert('Something went wrong while adding to cart.');
      }
    });
  }
}
