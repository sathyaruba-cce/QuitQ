import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-seller-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './seller-dashboard.html',
  styleUrls: ['./seller-dashboard.css']
})
export class SellerDashboardComponent implements OnInit {
  sellerName: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    const seller = this.authService.getLoggedInUser();
    this.sellerName = seller?.name || 'Seller';
  }

  navigateToAddProduct() {
    this.router.navigate(['/seller/add-product']);
  }
  navigateToManageProducts() {
  this.router.navigate(['/seller/manage-products']);
}

}
