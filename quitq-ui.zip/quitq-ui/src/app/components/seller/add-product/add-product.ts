// src/app/components/seller/add-product/add-product.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Product } from '../../../models/product.model';
import { SellerService } from '../../../services/seller';

@Component({
  selector: 'app-add-product',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-product.html',
  styleUrls: ['./add-product.css']
})
export class AddProductComponent {
  product: Product = {
    id: 0,
    name: '',
    category: '',
    description: '',
    price: 0,
    stock: 0
  };

  constructor(private sellerService: SellerService, private router: Router) {}

  onSubmit(): void {
    this.sellerService.addProduct(this.product).subscribe({
      next: () => {
        alert('Product added successfully!');
        this.router.navigate(['/seller-dashboard']);
      },
      error: () => alert('added product.')
    });
  }
}
