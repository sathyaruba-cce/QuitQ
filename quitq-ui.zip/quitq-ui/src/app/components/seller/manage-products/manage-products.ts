import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-manage-products',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './manage-products.html',
  styleUrls: ['./manage-products.css']
})
export class ManageProductsComponent implements OnInit {
  products: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadProducts();
  }

  // 🔵 Load all products from the backend
  loadProducts(): void {
    this.http.get<any[]>('http://localhost:8081/seller/products').subscribe({
      next: (data) => this.products = data,
      error: () => alert('Failed to load products')
    });
  }

  // 🔵 Mark selected product as out of stock
  markOutOfStock(productId: number): void {
    if (confirm('Are you sure you want to mark this product as out of stock?')) {
      this.http.patch(`http://localhost:8081/seller/product/${productId}/out-of-stock`, {}).subscribe({
        next: () => {
          alert('✅ Product marked as out of stock');

          // 🟢 Update the local product stock value to 0 directly
          const product = this.products.find(p => p.id === productId);
          if (product) {
            product.stock = 0;
          }
        },
        error: () => alert('❌ Failed to update product stock')
      });
    }
  }
}
