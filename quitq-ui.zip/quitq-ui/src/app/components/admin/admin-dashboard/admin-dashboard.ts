// src/app/components/admin/admin-dashboard/admin-dashboard.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, HttpClientModule, RouterModule],
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.css']
})
export class AdminDashboardComponent implements OnInit {
  users: any[] = [];
  sellers: any[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchUsers();
    this.fetchSellers();
  }

  fetchUsers(): void {
    this.http.get<any[]>('http://localhost:8081/admin/users').subscribe({
      next: (data) => this.users = data,
      error: () => alert('Failed to load users')
    });
  }

  fetchSellers(): void {
    this.http.get<any[]>('http://localhost:8081/admin/sellers').subscribe({
      next: (data) => this.sellers = data,
      error: () => alert('Failed to load sellers')
    });
  }

  deleteAccount(id: number): void {
    if (confirm('Are you sure you want to delete this account?')) {
      this.http.delete(`http://localhost:8081/admin/delete/${id}`).subscribe({
        next: () => {
          alert('Account deleted');
          this.fetchUsers();
          this.fetchSellers();
        },
        error: () => alert('Failed to delete account')
      });
    }
  }
}
