import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageSellers } from './manage-sellers';

describe('ManageSellers', () => {
  let component: ManageSellers;
  let fixture: ComponentFixture<ManageSellers>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ManageSellers]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageSellers);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
