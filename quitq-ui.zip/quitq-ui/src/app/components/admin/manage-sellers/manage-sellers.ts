// src/app/components/admin/manage-sellers/manage-sellers.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { SellerService, User } from '../../../services/seller';

@Component({
  standalone: true,
  selector: 'app-manage-sellers',
  imports: [CommonModule, HttpClientModule],
  templateUrl: './manage-sellers.html',
  styleUrls: ['./manage-sellers.css']
})
export class ManageSellersComponent implements OnInit {
  sellers: User[] = [];

  constructor(private sellerService: SellerService) {}

  ngOnInit(): void {
    this.sellerService.getSellers().subscribe(data => {
      this.sellers = data;
    });
  }

  deleteSeller(id: number): void {
  if (confirm('Are you sure you want to delete this seller?')) {
    this.sellerService.deleteSeller(id).subscribe(() => {
      this.sellers = this.sellers.filter(s => s.id !== id);  // ✅ removes from UI
    });
  }
}
}
