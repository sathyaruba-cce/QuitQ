import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule, RouterModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class RegisterComponent {
  user: {
    name: string;
    email: string;
    password: string;
    gender: string;
    contactNumber: string;
    address: string;
    role: string;
  } = {
    name: '',
    email: '',
    password: '',
    gender: '',
    contactNumber: '',
    address: '',
    role: ''
  };

  constructor(private http: HttpClient, private router: Router) {}

  registerUser(form?: NgForm) {
    if (form && form.invalid) {
      return;
    }

    const apiUrl = 'http://localhost:8081/api/auth/register';

    this.http.post(apiUrl, this.user).subscribe({
      next: () => {
        alert('✅ User registered successfully!');
        this.router.navigate(['/login']);
      },
      error: (err) => {
        console.error('❌ Registration failed:', err);
        alert(err.error?.message || 'Registration failed. Please try again.');
      }
    });
  }
}
