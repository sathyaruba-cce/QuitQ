import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../../services/product.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './navbar.html',
  styleUrls: ['./navbar.css']
})
export class NavbarComponent {
  searchQuery = '';
  suggestions: string[] = [];

  constructor(
    private router: Router,
    private productService: ProductService,
    private authService: AuthService
  ) {}

  goToSearch(): void {
    if (this.searchQuery.trim()) {
      this.router.navigate(['/products'], {
        queryParams: { q: this.searchQuery.trim() }
      });
      this.suggestions = [];
    }
  }

  onSearchChange(): void {
    const query = this.searchQuery.trim();
    if (query.length >= 2) {
      this.productService.searchProducts(query).subscribe({
        next: (products) => {
          this.suggestions = products.map(p => p.name);
        },
        error: () => (this.suggestions = [])
      });
    } else {
      this.suggestions = [];
    }
  }

  selectSuggestion(name: string): void {
    this.searchQuery = name;
    this.goToSearch();
  }

  isLoggedIn(): boolean {
    return !!this.authService.getToken();
  }

  getRole(): string {
    const user = this.authService.getLoggedInUser();
    return user?.role || '';
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
