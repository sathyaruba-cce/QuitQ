import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { Product } from '../../models/product.model';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-homepage',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './home.html',
  styleUrls: ['./home.css']
})
export class HomepageComponent implements OnInit {
  featuredProducts: (Product & { imageError?: boolean })[] = [];

  constructor(
    private productService: ProductService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.productService.getAllProducts().subscribe({
      next: (res) => {
        this.featuredProducts = res.map(p => ({ ...p, imageError: false }));
      },
      error: (err) => console.error('Failed to load products:', err)
    });
  }

  goToProduct(id: number): void {
    this.router.navigate(['/product-details', id]);

  }
}
