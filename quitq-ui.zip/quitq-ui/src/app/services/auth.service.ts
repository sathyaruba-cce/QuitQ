import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private apiUrl = 'http://localhost:8081/api/auth';  // ✅ Backend base URL

  constructor(private http: HttpClient) {}

  // ✅ LOGIN with storing token + user
  login(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, data).pipe(
      tap((res: any) => {
        // ✅ Store token and user info in localStorage
        localStorage.setItem('token', res.token);
        localStorage.setItem('loggedInUser', JSON.stringify(res.user));
        localStorage.setItem('email', res.user.email);
      })
    );
  }

  // ✅ REGISTER (no localStorage needed here)
  register(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, data);
  }

  // ✅ Helper: get logged-in user object
  getLoggedInUser(): any {
    return JSON.parse(localStorage.getItem('loggedInUser') || 'null');
  }

  // ✅ Helper: get logged-in user ID
  getLoggedInUserId(): number | null {
    const user = this.getLoggedInUser();
    return user ? user.id : null;
  }

  // ✅ Helper: get token
  getToken(): string | null {
    return localStorage.getItem('token');
  }
isLoggedIn(): boolean {
  const token = localStorage.getItem('token');
  return !!token; // returns true if token exists, false if null
}

  // ✅ Logout method
  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('loggedInUser');
  }
}
