import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface User {
  id: number;
  name: string;
  email: string;
  role: 'USER' | 'SELLER' | 'ADMIN';
  contactNumber?: string;
  gender?: string;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private adminBaseUrl = 'http://localhost:8081/admin';

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
  }

  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.adminBaseUrl}/users`, {
      headers: this.getAuthHeaders()
    });
  }

  getSellers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.adminBaseUrl}/sellers`, {
      headers: this.getAuthHeaders()
    });
  }

  deleteUser(id: number): Observable<any> {
  return this.http.delete(`${this.adminBaseUrl}/delete/${id}`, {
    headers: this.getAuthHeaders(),
    responseType: 'text' as 'json'  
  });
}

}
