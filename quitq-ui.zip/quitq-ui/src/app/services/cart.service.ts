import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CartItem } from '../models/cart.model';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private baseUrl = 'http://localhost:8081/cart';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  // ✅ Add item to cart using JWT
  addToCart(cartItem: { productId: number, quantity: number }): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.post(`${this.baseUrl}/add`, cartItem, { headers });
  }

  // ✅ Get cart items for logged-in user
  getCartItems(): Observable<CartItem[]> {
    const headers = this.getAuthHeaders();
    return this.http.get<CartItem[]>(`${this.baseUrl}`, { headers });
  }

  // ✅ Remove one item by productId
 removeItem(productId: number): Observable<string> {
  const headers = this.getAuthHeaders();
  return this.http.delete(`${this.baseUrl}/remove/${productId}`, {
    headers,
    responseType: 'text'  // ✅ Add this line
  });
}

  // ✅ Clear entire cart
  clearCart(): Observable<void> {
    const headers = this.getAuthHeaders();
    return this.http.delete<void>(`${this.baseUrl}/clear`, { headers });
  }

  // ✅ Update quantity of a product in cart
  updateCartItem(productId: number, quantity: number): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.put(`${this.baseUrl}/update`, { productId, quantity }, { headers });
  }

  // 🔐 Reuse: Get Auth header with token
  private getAuthHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
  }
}
