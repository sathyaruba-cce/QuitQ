import { Product } from '../models/product.model';

describe('Product Model Test', () => {
  let product: Product;

  beforeEach(() => {
    product = {
      id: 1,
      name: 'Wireless Mouse',
      description: 'A high-quality wireless mouse',
      price: 499,
      category: 'Electronics',
      stock: 20,
      imageError: false
    };
  });

  it('should create a product object', () => {
    expect(product).toBeTruthy(); // checks if product is not null or undefined
  });

  it('should have correct name', () => {
    expect(product.name).toBe('Wireless Mouse');
  });

  it('should have correct category', () => {
    expect(product.category).toBe('Electronics');
  });

  it('should have stock greater than zero', () => {
    expect(product.stock).toBeGreaterThan(0);
  });

  it('should not have image error initially', () => {
    expect(product.imageError).toBeFalse();
  });
});
