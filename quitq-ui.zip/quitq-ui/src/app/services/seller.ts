import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Product } from '../models/product.model';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service'; // ✅ Needed for token

export interface User {
  id: number;
  name: string;
  email: string;
  role: 'SELLER' | 'USER' | 'ADMIN';
  contactNumber?: string;
  gender?: string;
}

@Injectable({
  providedIn: 'root'
})
export class SellerService {
  private sellerBaseUrl = 'http://localhost:8081/seller'; // for seller-specific features
  private adminBaseUrl = 'http://localhost:8081/admin';   // for admin-related features

  constructor(private http: HttpClient, private authService: AuthService) {}

  // -----------------------------
  // ✅ SELLER FEATURES (existing)
  // -----------------------------

  getSellerProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.sellerBaseUrl}/products`, {
      headers: this.getAuthHeaders()
    });
  }

  markProductOutOfStock(id: number): Observable<void> {
    return this.http.patch<void>(`${this.sellerBaseUrl}/product/${id}/out-of-stock`, {}, {
      headers: this.getAuthHeaders()
    });
  }

  addProduct(product: Product): Observable<Product> {
    return this.http.post<Product>(`${this.sellerBaseUrl}/product`, product, {
      headers: this.getAuthHeaders()
    });
  }

  // -----------------------------
  // 🔄 ADMIN FEATURES (new)
  // -----------------------------

  // ✅ Get all sellers (for admin)
  getSellers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.adminBaseUrl}/sellers`, {
      headers: this.getAuthHeaders()
    });
  }

  // ✅ Delete seller by ID (for admin)
 deleteSeller(id: number): Observable<any> {
  return this.http.delete(`${this.adminBaseUrl}/delete/${id}`, {
    headers: this.getAuthHeaders(),
    responseType: 'text' as 'json' // ✅ This fixes the parsing error
  });
}
  // -----------------------------
  // 🔐 Auth Header
  // -----------------------------

  private getAuthHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
  }
}
