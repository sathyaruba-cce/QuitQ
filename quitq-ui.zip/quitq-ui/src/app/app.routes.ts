// src/app/app.routes.ts
import { Routes } from '@angular/router';
import { authGuard } from './guards/auth-guard';
import { roleGuard } from './guards/role-guard';

export const routes: Routes = [
  // Home
  {
    path: '',
    loadComponent: () =>
      import('./components/home/home').then(m => m.HomepageComponent)
  },

  // Auth
  {
    path: 'login',
    loadComponent: () =>
      import('./components/auth/login/login').then(m => m.LoginComponent)
  },
  {
    path: 'register',
    loadComponent: () =>
      import('./components/auth/register/register').then(m => m.RegisterComponent)
  },

  // User
  {
    path: 'products',
    loadComponent: () =>
      import('./components/user/product-list/product-list').then(m => m.ProductListComponent)
  },
  {
    path: 'product-details/:id',
    loadComponent: () =>
      import('./components/user/product-details/product-details').then(m => m.ProductDetailsComponent)
  },
  {
    path: 'cart',
    canActivate: [authGuard, roleGuard],
    data: { role: 'USER' },
    loadComponent: () =>
      import('./components/user/cart/cart').then(m => m.CartComponent)
  },
  {
    path: 'checkout',
    canActivate: [authGuard, roleGuard],
    data: { role: 'USER' },
    loadComponent: () =>
      import('./components/user/checkout/checkout').then(m => m.CheckoutComponent)
  },
  {
    path: 'user/order-history',
    canActivate: [authGuard, roleGuard],
    data: { role: 'USER' },
    loadComponent: () =>
      import('./components/user/order-history/order-history').then(m => m.OrderHistoryComponent)
  },

  // Seller
  {
    path: 'seller-dashboard',
    canActivate: [authGuard, roleGuard],
    data: { role: 'SELLER' },
    loadComponent: () =>
      import('./components/seller/seller-dashboard/seller-dashboard').then(m => m.SellerDashboardComponent)
  },
  {
    path: 'seller/add-product',
    canActivate: [authGuard, roleGuard],
    data: { role: 'SELLER' },
    loadComponent: () =>
      import('./components/seller/add-product/add-product').then(m => m.AddProductComponent)
  },
  {
    path: 'seller/manage-products',
    canActivate: [authGuard, roleGuard],
    data: { role: 'SELLER' },
    loadComponent: () =>
      import('./components/seller/manage-products/manage-products').then(m => m.ManageProductsComponent)
  },

  // Admin
  {
    path: 'admin/admin-dashboard',
    canActivate: [authGuard, roleGuard],
    data: { role: 'ADMIN' },
    loadComponent: () =>
      import('./components/admin/admin-dashboard/admin-dashboard').then(m => m.AdminDashboardComponent)
  },
  {
    path: 'admin/users',
    canActivate: [authGuard, roleGuard],
    data: { role: 'ADMIN' },
    loadComponent: () =>
      import('./components/admin/manage-users/manage-users').then(m => m.ManageUsersComponent)
  },
  {
    path: 'admin/sellers',
    canActivate: [authGuard, roleGuard],
    data: { role: 'ADMIN' },
    loadComponent: () =>
      import('./components/admin/manage-sellers/manage-sellers').then(m => m.ManageSellersComponent)
  },

  // Unauthorized
  {
    path: 'unauthorized',
    loadComponent: () =>
      import('./components/unauthorized/unauthorized').then(m => m.UnauthorizedComponent)
  },

  // Fallback
  {
    path: '**',
    redirectTo: '',
    pathMatch: 'full'
  }
];
