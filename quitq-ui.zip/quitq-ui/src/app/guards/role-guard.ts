// src/app/guards/role.guard.ts
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const roleGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const expectedRole = route.data?.['role']; // gets role from route
  const userData = localStorage.getItem('loggedInUser');

  if (userData) {
    const parsed = JSON.parse(userData);
    const userRole = parsed?.role;

    if (userRole === expectedRole) {
      return true;
    }
  }

  // redirect if not authorized
  return router.createUrlTree(['/unauthorized']);
};
