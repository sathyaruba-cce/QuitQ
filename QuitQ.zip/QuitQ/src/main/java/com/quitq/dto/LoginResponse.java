// File: LoginResponse.java
package com.quitq.dto;

import com.quitq.entity.User;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LoginResponse {
    private String token;
    private User user; // Send the full user object back
}
