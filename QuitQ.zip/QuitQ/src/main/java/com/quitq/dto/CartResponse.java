package com.quitq.dto;

import com.quitq.entity.Product;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CartResponse {
    private Long id;
    private Product product;     // ✅ Send full product object
    private Integer quantity;
    private Double totalPrice;
}
