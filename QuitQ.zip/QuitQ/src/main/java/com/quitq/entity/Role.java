package com.quitq.entity;

public enum Role {
    USER,
    SELLER,
    ADMIN
}