// AdminController.java - Updated for full admin use cases
package com.quitq.controller;

import com.quitq.entity.Product;
import com.quitq.entity.Role;
import com.quitq.entity.User;
import com.quitq.repository.ProductRepository;
import com.quitq.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/admin")

@PreAuthorize("hasAuthority('ADMIN')") 
public class AdminController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    // User Management
    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userRepository.findAll().stream()
                .filter(u -> u.getRole() == Role.USER)
                .collect(Collectors.toList());
    }

    @GetMapping("/sellers")
    public List<User> getAllSellers() {
        return userRepository.findAll().stream()
                .filter(u -> u.getRole() == Role.SELLER)
                .collect(Collectors.toList());
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteAccount(@PathVariable Long id) {
        userRepository.deleteById(id);
        return ResponseEntity.ok("Account deleted successfully");
    }

    // Product Catalog Management
    @PostMapping("/product")
    public ResponseEntity<String> addProduct(@RequestBody Product product) {
        productRepository.save(product);
        return ResponseEntity.ok("Product category added");
    }

    @PutMapping("/product/{id}")
    public ResponseEntity<String> updateProduct(@PathVariable Long id, @RequestBody Product updatedProduct) {
        Product product = productRepository.findById(id).orElseThrow();
        product.setName(updatedProduct.getName());
        product.setPrice(updatedProduct.getPrice());
        product.setDescription(updatedProduct.getDescription());
        productRepository.save(product);
        return ResponseEntity.ok("Product updated");
    }

    @DeleteMapping("/product/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable Long id) {
        productRepository.deleteById(id);
        return ResponseEntity.ok("Product removed");
    }

    // Generate Reports (Simple list view)
    @GetMapping("/report")
    public List<User> generateReport() {
        return userRepository.findAll();
    }
}
