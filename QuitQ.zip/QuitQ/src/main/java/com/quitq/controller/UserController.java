package com.quitq.controller;

import com.quitq.entity.Order;
import com.quitq.entity.Product;
import com.quitq.repository.OrderRepository;
import com.quitq.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
@PreAuthorize("hasAuthority('USER')")  // ✅ Use 'hasAuthority' instead of 'hasRole'
public class UserController {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private OrderRepository orderRepository;

    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }
    
    
    @GetMapping("/products/search")
    public List<Product> searchProducts(@RequestParam("q") String keyword) {
        return productRepository.findAll().stream()
                .filter(p -> p.getName().toLowerCase().contains(keyword.toLowerCase()))
                .toList();
    }


    @GetMapping("/products/{id}")
    public ResponseEntity<Product> getProductDetails(@PathVariable Long id) {
        Product product = productRepository.findById(id).orElseThrow();
        return ResponseEntity.ok(product);
    }

    @GetMapping("/orders")
    public List<Order> getUserOrders() {
        return orderRepository.findAll(); // Add filtering later
    }
}
