// SellerController.java - Updated with full seller use cases
package com.quitq.controller;

import com.quitq.entity.Order;
import com.quitq.entity.Product;
import com.quitq.repository.OrderRepository;
import com.quitq.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/seller")
@PreAuthorize("hasAuthority('SELLER')")
public class SellerController {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private OrderRepository orderRepository;

    // Add product
    @PostMapping("/product")
    public ResponseEntity<String> addProduct(@RequestBody Product product) {
        productRepository.save(product);
        return ResponseEntity.ok("Product added");
    }

    // Update product (name, price, stock, description)
    @PutMapping("/product/{id}")
    public ResponseEntity<String> updateProduct(@PathVariable Long id, @RequestBody Product updatedProduct) {
        Product product = productRepository.findById(id).orElseThrow();
        product.setName(updatedProduct.getName());
        product.setPrice(updatedProduct.getPrice());
        product.setStock(updatedProduct.getStock());
        product.setCategory(updatedProduct.getCategory());
        product.setDescription(updatedProduct.getDescription());
        productRepository.save(product);
        return ResponseEntity.ok("Product updated");
    }

    // Mark product out of stock
    @PatchMapping("/product/{id}/out-of-stock")
    public ResponseEntity<?> markOutOfStock(@PathVariable Long id) {
        Product product = productRepository.findById(id).orElseThrow();
        product.setStock(0);
        productRepository.save(product);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Product marked as out of stock");

        return ResponseEntity.ok(response); // ✅ sends { "message": "..." }
    }


    // View all products
    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return productRepository.findAll(); // You can filter by seller later if needed
    }

    // View all orders
    @GetMapping("/orders")
    public List<Order> viewOrders() {
        return orderRepository.findAll(); // Filter by seller's product later if needed
    }

    // View order history
    @GetMapping("/orders/history")
    public List<Order> orderHistory() {
        return orderRepository.findAll(); // Simple list for now
    }
}
