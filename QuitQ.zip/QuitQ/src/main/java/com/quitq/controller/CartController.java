package com.quitq.controller;

import com.quitq.dto.CartRequest;
import com.quitq.dto.CartResponse;
import com.quitq.security.JwtUtil;
import com.quitq.service.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/cart")
@RequiredArgsConstructor

public class CartController {

    private final CartService cartService;
    private final JwtUtil jwtUtil;

    private String extractEmailFromToken(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null) {
            String token = authHeader.startsWith("Bearer ") ? authHeader.substring(7) : authHeader;
            return jwtUtil.extractUsername(token);
        }
        throw new RuntimeException("Authorization header missing");
    }

    @PostMapping("/add")
    public ResponseEntity<Map<String, String>> addToCart(@RequestBody CartRequest request, HttpServletRequest httpRequest)
    {    String email = extractEmailFromToken(httpRequest);
        cartService.addToCart(email, request);
       
        return ResponseEntity.ok(Map.of("message", "Item added to cart"));
    }

    @GetMapping
    public ResponseEntity<List<CartResponse>> getCart(HttpServletRequest httpRequest) {
        String email = extractEmailFromToken(httpRequest);
        return ResponseEntity.ok(cartService.getUserCart(email));
    }

    @PutMapping("/update")
    public ResponseEntity<String> updateCart(@RequestBody CartRequest request, HttpServletRequest httpRequest) {
        String email = extractEmailFromToken(httpRequest);
        cartService.updateCartItem(email, request);
        return ResponseEntity.ok("Cart updated");
    }

    @DeleteMapping("/remove/{productId}")
    public ResponseEntity<String> removeFromCart(@PathVariable Long productId, HttpServletRequest httpRequest) {
        String email = extractEmailFromToken(httpRequest);
        cartService.removeCartItem(email, productId);
        return ResponseEntity.ok("Item removed from cart");
    }

    @DeleteMapping("/clear")
    public ResponseEntity<String> clearCart(HttpServletRequest httpRequest) {
        String email = extractEmailFromToken(httpRequest);
        cartService.clearCart(email);
        return ResponseEntity.ok("Cart cleared");
    }
}
