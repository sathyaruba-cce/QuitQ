package com.quitq.service;

import com.quitq.dto.AuthRequest;
import com.quitq.dto.LoginRequest;
import com.quitq.dto.AuthResponse;
import com.quitq.entity.Role;
import com.quitq.entity.User;
import com.quitq.repository.UserRepository;
import com.quitq.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private JwtUtil jwtUtil;

    // ✅ Register user (still uses AuthRequest)
    public String register(AuthRequest request) {
        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(request.getPassword());
        user.setGender(request.getGender());
        user.setContactNumber(request.getContactNumber());
        user.setAddress(request.getAddress());
        user.setRole(Role.valueOf(request.getRole()));  // Expects "USER", "SELLER", etc.

        userRepo.save(user);
        return "Registration successful";
    }

    // ✅ Login user (now uses LoginRequest)
    public AuthResponse login(LoginRequest request) {
        User user = userRepo.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!user.getPassword().equals(request.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        String token = jwtUtil.generateToken(user.getEmail(), user.getRole().toString());

        // You can include more fields like role, email, etc.
        return new AuthResponse(token, user); // ✅ Correct
  }
}
