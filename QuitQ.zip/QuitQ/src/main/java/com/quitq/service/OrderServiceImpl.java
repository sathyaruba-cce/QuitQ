package com.quitq.service;

import com.quitq.entity.Order;
import com.quitq.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Override
    public Order placeOrder(Order order) {
        order.setOrderDate(LocalDateTime.now());
        order.setStatus("PENDING");
        return orderRepository.save(order);
    }

    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    @Override
    public List<Order> getOrdersByUser(String email) {
        return orderRepository.findByUserEmail(email);
    }

    @Override
    public Order updateOrder(Long id, Order updatedOrder) {
        Optional<Order> optionalOrder = orderRepository.findById(id);
        if (optionalOrder.isPresent()) {
            Order existingOrder = optionalOrder.get();
            // Update the fields
            existingOrder.setStatus(updatedOrder.getStatus());
            existingOrder.setItems(updatedOrder.getItems());
            existingOrder.setTotalAmount(updatedOrder.getTotalAmount());
            // You can add other fields to update
            return orderRepository.save(existingOrder);
        } else {
            throw new RuntimeException("Order with ID " + id + " not found");
        }
    }

    @Override
    public void deleteOrder(Long id) {
        if (orderRepository.existsById(id)) {
            orderRepository.deleteById(id);
        } else {
            throw new RuntimeException("Order with ID " + id + " not found");
        }
    }
}
