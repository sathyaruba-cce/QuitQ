package com.quitq.repository;

import com.quitq.entity.CartItem;
import com.quitq.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.repository.query.Param;

import java.util.List;

@Repository
public interface CartRepository extends JpaRepository<CartItem, Long> {

    // ✅ Fetch all cart items for a user
    List<CartItem> findByUser(User user);

    // ✅ Remove cart item by user and product (must be in a transaction)
    @Modifying
    @Transactional
    @Query("DELETE FROM CartItem c WHERE c.user = :user AND c.product.id = :productId")
    void deleteByUserAndProductId(@Param("user") User user, @Param("productId") Long productId);
}
