package com.quitq.QuitQ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuitQApplicationTests {

	@Test
	void contextLoads() {
	}

}
