package com.quitq.service;

import com.quitq.dto.ProductRequest;
import com.quitq.dto.ProductResponse;
import com.quitq.entity.Product;
import com.quitq.repository.ProductRepository;
import com.quitq.service.ProductServiceImpl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private ProductServiceImpl productService;

    @Test
    void testAddProduct() {
        ProductRequest request = new ProductRequest();
        request.setName("Smart Watch");
        request.setDescription("Fitness band");
        request.setPrice(1999.0);
        request.setCategory("Electronics");
        request.setStock(20);

        Product savedProduct = Product.builder()
                .id(1L)
                .name("Smart Watch")
                .description("Fitness band")
                .price(1999.0)
                .category("Electronics")
                .stock(20)
                .build();

        when(productRepository.save(any(Product.class))).thenReturn(savedProduct);

        ProductResponse response = productService.addProduct(request);

        assertNotNull(response);
        assertEquals("Smart Watch", response.getName());
        assertEquals(1999.0, response.getPrice());
        verify(productRepository).save(any(Product.class));
    }

    @Test
    void testGetAllProducts() {
        Product product1 = Product.builder().id(1L).name("Phone").category("Electronics").description("Mobile").price(5000.0).stock(10).build();
        Product product2 = Product.builder().id(2L).name("Laptop").category("Electronics").description("Workstation").price(45000.0).stock(5).build();

        when(productRepository.findAll()).thenReturn(List.of(product1, product2));

        List<ProductResponse> products = productService.getAllProducts();

        assertEquals(2, products.size());
        assertEquals("Phone", products.get(0).getName());
    }

    @Test
    void testGetProductById() {
        Product product = Product.builder().id(1L).name("Tablet").description("10 inch").category("Electronics").price(9999.0).stock(15).build();

        when(productRepository.findById(1L)).thenReturn(Optional.of(product));

        ProductResponse response = productService.getProductById(1L);

        assertNotNull(response);
        assertEquals("Tablet", response.getName());
    }

    @Test
    void testDeleteProduct() {
        Long productId = 5L;

        // Act
        productService.deleteProduct(productId);

        // Assert
        verify(productRepository).deleteById(productId);
    }
    @Test
    void testExistsProductById() {
        Long id = 10L;

        when(productRepository.existsById(id)).thenReturn(true);

        boolean result = productService.existsProductById(id);

        assertTrue(result);
        verify(productRepository).existsById(id);
    }
}
